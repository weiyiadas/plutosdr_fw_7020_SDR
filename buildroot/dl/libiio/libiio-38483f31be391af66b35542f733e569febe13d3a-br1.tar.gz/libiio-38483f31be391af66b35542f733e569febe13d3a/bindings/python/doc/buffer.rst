Buffer
==================

Members
--------------
.. autoclass:: iio.Buffer
   :members:
