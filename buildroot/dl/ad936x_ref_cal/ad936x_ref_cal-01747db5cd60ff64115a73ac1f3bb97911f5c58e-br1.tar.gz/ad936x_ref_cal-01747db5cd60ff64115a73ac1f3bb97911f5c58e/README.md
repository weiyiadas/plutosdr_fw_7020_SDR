# plutosdr scripts
Small scripts and examples to make interacting with PlutoSDR easier.

Most of these were created during the development cycle of the PlutoSDR, to ease programming and upgrading, or testing devices.


