Contexts
==================

Members
--------------
.. autoclass:: iio.Context
   :members:

.. autoclass:: iio.LocalContext
   :members:
   :inherited-members:

.. autoclass:: iio.XMLContext
   :members:
   :inherited-members:

.. autoclass:: iio.NetworkContext
   :members:
   :inherited-members:

